-- Create registrations table for Overra AI Academy
CREATE TABLE IF NOT EXISTS public.registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  school TEXT,
  area_of_interest TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- Enable Row Level Security
ALTER TABLE public.registrations ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to insert registrations (public form)
CREATE POLICY "Anyone can submit registrations"
ON public.registrations
FOR INSERT
TO anon
WITH CHECK (true);

-- Create policy to allow service role to read all registrations (for admin access)
CREATE POLICY "Service role can read all registrations"
ON public.registrations
FOR SELECT
TO service_role
USING (true);

-- Create index on email for faster lookups
CREATE INDEX IF NOT EXISTS idx_registrations_email ON public.registrations(email);

-- Create index on created_at for sorting
CREATE INDEX IF NOT EXISTS idx_registrations_created_at ON public.registrations(created_at DESC);