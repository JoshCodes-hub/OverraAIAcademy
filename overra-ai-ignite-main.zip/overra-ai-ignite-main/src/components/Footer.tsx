import { Facebook, Twitter, Instagram, Linkedin, Mail } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card/50 border-t border-border/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-black">
              <span className="gradient-text">Overra AI</span> Academy
            </h3>
            <p className="text-muted-foreground leading-relaxed">
              Raising a generation of AI thinkers and innovators. Join us in shaping the future of technology.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold text-foreground">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a 
                  href="#about" 
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a 
                  href="#registration" 
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Join Now
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Programs
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold text-foreground">Connect With Us</h4>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="p-3 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors group"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              </a>
              <a 
                href="#" 
                className="p-3 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors group"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              </a>
              <a 
                href="#" 
                className="p-3 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors group"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              </a>
              <a 
                href="#" 
                className="p-3 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors group"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              </a>
              <a 
                href="mailto:info@overraai.academy" 
                className="p-3 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors group"
                aria-label="Email"
              >
                <Mail className="w-5 h-5 text-primary group-hover:scale-110 transition-transform" />
              </a>
            </div>
            <p className="text-sm text-muted-foreground pt-4">
              <strong>Email:</strong> info@overraai.academy
            </p>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/50 text-center">
          <p className="text-sm text-muted-foreground">
            © {currentYear} Overra AI Academy. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Powered by <span className="text-primary font-semibold">Overra AI</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
