import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";
import founderAvatar from "@/assets/founder-avatar.jpg";

const FounderSection = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/30">
      <div className="max-w-5xl mx-auto">
        <Card className="bg-card/80 backdrop-blur-sm border-border/50 overflow-hidden hover:shadow-glow transition-all duration-500">
          <CardContent className="p-0">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              {/* Image Side */}
              <div className="relative h-full min-h-[400px] md:min-h-[500px] overflow-hidden">
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${founderAvatar})` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-card/80 to-transparent md:from-transparent md:to-card/80" />
                </div>
              </div>

              {/* Content Side */}
              <div className="p-8 md:p-12 animate-fade-in">
                <div className="mb-6">
                  <div className="inline-flex p-3 rounded-xl bg-primary/10 mb-4">
                    <Quote className="w-8 h-8 text-primary" />
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-black mb-2">
                    Meet the <span className="gradient-text">Visionary</span>
                  </h2>
                  <p className="text-xl text-secondary font-semibold">
                    Abayomi Joshua (Overcomer)
                  </p>
                  <p className="text-muted-foreground mt-2">
                    AI Evangelist & Founder
                  </p>
                </div>

                <blockquote className="text-lg text-foreground leading-relaxed mb-6 italic border-l-4 border-primary pl-6">
                  "The future belongs to those who dare to think in AI."
                </blockquote>

                <p className="text-muted-foreground leading-relaxed mb-4">
                  An evangelist of Artificial Intelligence with a passion for empowering young minds, 
                  Abayomi Joshua founded Overra AI Academy to bridge the gap between traditional education 
                  and the AI-powered future.
                </p>

                <p className="text-muted-foreground leading-relaxed">
                  His mission: To inspire and train the next generation of innovators, starting from 
                  secondary school, to understand and harness the power of AI for solving real-world problems.
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  {["AI Education", "Innovation", "Youth Empowerment"].map((tag) => (
                    <span 
                      key={tag}
                      className="px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

export default FounderSection;
