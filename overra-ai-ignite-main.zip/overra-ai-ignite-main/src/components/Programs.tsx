import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GraduationCap, FlaskConical, Trophy } from "lucide-react";

const programs = [
  {
    icon: GraduationCap,
    title: "AI for Schools",
    description: "Comprehensive AI curriculum designed for secondary school students. Interactive lessons, hands-on projects, and mentorship from industry experts.",
    highlights: ["Beginner-friendly", "Project-based learning", "Certificate programs"],
  },
  {
    icon: FlaskConical,
    title: "Overra Labs",
    description: "Advanced innovation hub where students build real AI solutions. Access to tools, resources, and guidance to turn ideas into working prototypes.",
    highlights: ["Cutting-edge tools", "Expert mentorship", "Collaborative environment"],
  },
  {
    icon: Trophy,
    title: "Innovation Challenges",
    description: "Regular competitions and hackathons to solve real-world problems using AI. Win prizes, gain recognition, and make an impact.",
    highlights: ["Cash prizes", "Industry exposure", "Portfolio building"],
  },
];

const Programs = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-background relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-20 right-20 w-96 h-96 bg-secondary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-20 left-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl sm:text-5xl font-black mb-4">
            Our <span className="gradient-text-secondary">Programs</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Multiple pathways to master AI and build your future in technology
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {programs.map((program, index) => {
            const Icon = program.icon;
            return (
              <Card 
                key={index}
                className="group bg-card/50 backdrop-blur-sm border-border/50 hover:border-secondary/50 transition-all duration-500 animate-fade-in-up hover:shadow-glow-secondary hover:-translate-y-2"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <CardHeader>
                  <div className="inline-flex p-4 rounded-2xl bg-secondary/10 mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-10 h-10 text-secondary" strokeWidth={2} />
                  </div>
                  <CardTitle className="text-2xl group-hover:text-secondary transition-colors">
                    {program.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {program.description}
                  </p>
                  
                  <div className="space-y-2">
                    {program.highlights.map((highlight, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                        <span className="text-sm text-foreground">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Programs;
