import { Brain, Rocket, Globe } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const reasons = [
  {
    icon: Brain,
    title: "Learn AI",
    description: "Master artificial intelligence from fundamentals to advanced applications. Understand how AI is shaping our future.",
    color: "primary",
  },
  {
    icon: Rocket,
    title: "Build Projects",
    description: "Create real-world AI solutions that solve actual problems. Turn your ideas into impactful innovations.",
    color: "secondary",
  },
  {
    icon: Globe,
    title: "Impact the Future",
    description: "Be part of a generation that uses AI to create positive change. Shape the future with technology.",
    color: "primary",
  },
];

const WhyOverra = () => {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8 bg-background relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl sm:text-5xl font-black mb-4">
            Why <span className="gradient-text">Overra AI Academy</span>?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join a movement that's transforming education and empowering the next generation of innovators
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <Card 
                key={index}
                className="group bg-card/50 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all duration-500 animate-fade-in-up hover:shadow-glow hover:-translate-y-2"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <CardContent className="p-8 text-center">
                  <div className={`inline-flex p-4 rounded-2xl bg-${reason.color}/10 mb-6 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon 
                      className={`w-10 h-10 text-${reason.color}`} 
                      strokeWidth={2}
                    />
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-4 group-hover:text-primary transition-colors">
                    {reason.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {reason.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default WhyOverra;
