import { Card, CardContent } from "@/components/ui/card";
import { Quote, Star } from "lucide-react";

const testimonials = [
  {
    name: "Chiamaka O.",
    role: "Secondary School Student",
    content: "Overra AI Academy changed my perspective on technology. I never thought I could build my own AI model, but now I'm creating solutions for my community!",
    rating: 5,
  },
  {
    name: "Emmanuel T.",
    role: "Innovation Challenge Winner",
    content: "The mentorship and resources at Overra Labs are incredible. I went from knowing nothing about AI to winning a national competition in just 6 months.",
    rating: 5,
  },
  {
    name: "Blessing N.",
    role: "AI for Schools Graduate",
    content: "This program opened doors I didn't know existed. The practical approach to learning AI has prepared me for university and beyond.",
    rating: 5,
  },
];

const Testimonials = () => {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/20">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl sm:text-5xl font-black mb-4">
            <span className="gradient-text">Student Success</span> Stories
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real stories from students who are already shaping the future with AI
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="group bg-card/80 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all duration-500 animate-fade-in-up hover:shadow-glow hover:-translate-y-2"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <CardContent className="p-8 space-y-4">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star 
                      key={i} 
                      className="w-5 h-5 fill-secondary text-secondary" 
                    />
                  ))}
                </div>

                <div className="relative">
                  <Quote className="absolute -top-2 -left-2 w-8 h-8 text-primary/20" />
                  <p className="text-muted-foreground leading-relaxed pl-6">
                    "{testimonial.content}"
                  </p>
                </div>

                <div className="pt-4 border-t border-border/50">
                  <p className="font-semibold text-foreground">
                    {testimonial.name}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.role}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
