import Hero from "@/components/Hero";
import WhyOverra from "@/components/WhyOverra";
import FounderSection from "@/components/FounderSection";
import Programs from "@/components/Programs";
import RegistrationForm from "@/components/RegistrationForm";
import Testimonials from "@/components/Testimonials";
import Footer from "@/components/Footer";
import Chatbot from "@/components/Chatbot";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <WhyOverra />
      <FounderSection />
      <Programs />
      <Testimonials />
      <RegistrationForm />
      <Footer />
      <Chatbot />
    </div>
  );
};

export default Index;
